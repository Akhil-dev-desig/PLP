import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import Login from './components/login.component';
import Home from './components/home.component';
import AddAddvertisements from './components/addAddvertisement.component'
import { BrowserRouter as Router, Route, Link } from 'react-router-dom';
import Footer from './components/footer.component';
import List from './components/list.component'
import ProductsList from './components/productsList.component';
import Account from './components/signInAccount.component'
import Register from './components/register.component';
import Header from './components/header.component'
import DisplayProduct from './components/displayProduct.component';
//const currentUser = JSON.parse(localStorage.getItem('UserObject'));
import ContactUs from './components/contactus.component';
import About from './components/about.component';
class App extends Component {
 
    //console.log(this.props);


  render(){
  return (


    <Router>

    
        <Route path='/' exact component={Home} />
        <Route path='/home' exact component={Home} />
        <Route path='/user/login' exact component={Login} />
        <Route path='/user/register' exact component={Register} />
        {/* <Route path='/register' component={Register} /> */}
        <Route path='/footer' component={Footer} />
        <Route path="/list" component={List} />
        <Route path="/productsList/:category" component={ProductsList} />
        <Route exact path='/post' component={AddAddvertisements} />
        <Route exact path='/item/:id' component={DisplayProduct} />
       <Route exact path='/myaccount' component={Account} />
       <Route path ="/contactus" component={ContactUs}/>
      <Route path="/about" component={About}/>
      
        

    </Router>


      );
    }
  }
    
    export default App;
