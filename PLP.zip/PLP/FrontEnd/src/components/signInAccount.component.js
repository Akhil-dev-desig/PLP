import React from 'react';
import Header from './header.component'
import MyAdd from './layouts/myadd.component';
import Footer from './footer.component';
import '../static/css/account.css';


class Account extends React.Component {
    constructor(props) {
        super(props);
        this.state = {};
    }
    render() {
        return (

          
            <div>
                  <Header/>
                <div className="container">
               
                    <ul className="nav nav-tabs md-tabs nav-justified">
                        <li className="nav-item">
                            <a className="nav-link active" data-toggle="tab" href="#panel1" role="tab">You'r Ads</a>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link" data-toggle="tab" href="#panel2" role="tab">Messages</a>
                        </li>
                        
                    </ul>
                    <div className="tab-content card" id="tabcard">

                        <div className="tab-pane fade in show active" id="panel1" role="tabpanel">
                           

                            <MyAdd />
                        </div>

                        <div className="tab-pane fade" id="panel2" role="tabpanel">
                            <br />
                            <p>Thank You For Using this App.</p>
                            <p></p>
                        </div>

                        <div className="tab-pane fade" id="panel3" role="tabpanel">
                            <br />
                        </div>

                    </div>
                </div>
                <Footer />
            </div>

        );
    }
}

export default Account;