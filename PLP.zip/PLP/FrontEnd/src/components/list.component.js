import React from 'react';
import { NavLink } from 'react-router-dom';
import '../static/css/app.css';
import Header from './header.component';
import Footer from './footer.component';
import { category } from '../config/category';


class List extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            userName: '',
            category: [],
            place: ''
        };
    }
    componentDidMount() {
        this.setState({ category: category })

        var input = document.getElementById('location');
        var options = {
            types: ['(cities)'],
            componentRestrictions: { country: "INDIA" }
        };
        // let autoComplete = new window.google.maps.places.Autocomplete(input, options);
        // autoComplete.addListener('place_changed', () => {
        //     var place = autoComplete.getPlace().name;

        //     const upper = this.capital(place);
        //     window.location = '/cities/' + upper;
        //     console.log(upper);

        // });
    }
    capital = (str) => {
        var splitStr = str.toLowerCase().split(' ');
        for (var i = 0; i < splitStr.length; i++) {
            // You do not need to check if i is larger than splitStr length, as your for does that for you
            // Assign it back to the array
            splitStr[i] = splitStr[i].charAt(0).toUpperCase() + splitStr[i].substring(1);
        }
        // Directly return the joined string
        return splitStr.join(' ');
    }


    render() {

        return (
            <div  style={{backgroundImage:"url(data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBw0NDQ8NDQ8NDQ0NDQ0ODQ0NDQ8NDQ4NFREWFxcRFRUYHSggGB0lGxUVITEtJSsuLi4uFx8zODMsNygtLisBCgoKDg0OFxAQGi0mHR4tLS0tKy0tLSstLSsrLS0rKy0rKy0uLS0tKy0rKystLSstLS0tLS0rLS0rLS0tLSstLf/AABEIAKgBLAMBIgACEQEDEQH/xAAbAAACAwEBAQAAAAAAAAAAAAACAwABBAUGB//EADIQAAMAAgECBQIFAwQDAQAAAAABAgMREgQhBRMxQVFhgQYicZGhMkLwFCOxwXLh8RX/xAAYAQADAQEAAAAAAAAAAAAAAAABAgMABP/EACQRAQEAAwACAwACAgMAAAAAAAABAhESAyETMUFRwQSBIjJh/9oADAMBAAIRAxEAPwD4wQhZcFF6LLCGw6JoLRejabYdE0GkXxDoNl8S+IziXxNoOiuJOI7iXxDy3RPAnAfwL4G5Dpn4F+WaOBfAPIds3lk8s08C/LNy3bL5ZPLNXlk8s3Ldsnlk4GrgTyzct2y8CcDTwI4NyPbNwK4GjgTgDlumfiTiP4lcTcj0RxJodxK4g0OytFaG6K0bTbL0TQeitA0OwaIEUYVFBFAZEEikEghULSIkEkEESLSLSDSG0W0KQSkJIJSHRbQKQlIxSEpG0W0tSWoGqQlI3JeilBagcpCUB5L0TwL4D+BfAbkvTPwL4GjgXwNyHbNwJwNPAnAPLdsvArgauBXAHI9s3ApwaeBTgHI9MvArgaXILkHJpkzOSnJocguRdD0zuQXJocgOQaNKS5BaHOQWhdGlJaKaGNAtC6PstooNoFgELKCYIploJAoZIYFWkGkUkGkPCWokGkRIYkNIS1SQaRakNSPInapSEpDUhqR5CXIEr/jXomFMb7Lu32SXq2GpDxxyaUp020pU7bbfolr3G0W5FqQ1Ax42m00002mmtNNezQSkaYkuRakJQNUlqRuS9FcC+A7iTiHkvRPAnAfxJxNy3TPwKcGjiU5NyPTPwBcmhyC5BcRmTM5BcmlyA5EsPMmdyA5NDkFyLYaZM7kByaHIDQth5kzuQHI9yA0JYeUhoFoc0A0LYpKS0C0MaAYlPC2CGwGLTQUjJFyNkMCjlBygZQ2UUidXKGSipQ2UPIlaiQyZJKGSikidqTIakuUMlDyJ2l1PZ/oHgpxqpeqlppr1TXuMUgLpJ+aSfsn2/wDQdX8L1P1p6vrK6nLeet8snHm3r81qJVV2+Wm/uAp9F667L9Cu0amV+i+Edz8L+A34l1H+nx5MeKuF3yyb02l2la+Xr7bftob1jN38LbbfX646kJSP6jp6xZLxWtXju8draerltNb/AFQKkpIlaXxL4jOJfEbQdFcScR3EribTdE8SnI/iU5BpuiHILke5Bcg0aZM7kByaHIDkWw8yZ3IDk0OQHIlh5WepF1JppCqQlh5SGhdSPpC6QlikpFIXSH0hdInYrKRSAobSF0JVITQDGULZOqQUjZFyNkMDI2RsoXI6UViNHKGSipQyUVkRtFKGSipQ2UUkTtXKNHTSnXf/ABipQzfFN/C2UnpLK7bMkLi9/H8mdSBhqq702/8Ag7XQ9N0uTpM7uqjqcX+7jpv/AG7hLvic/L9n86GuU+05L9OLlSTTfbfYb5/Bcpty16Oa00FeOalqltfAE9Dj361a9t3VT+zNZd+m3jr2dOWsreWklWSqtqVxW299l7DJxt+haR0PD8afxv6lNcxPe6wPE17FcTu9Zgni9a2km9ei9v8Ak4zXcON2GU0XxJxGaI0NouyuJTkbousbXdpr7A02yHILkc0C0DRpSHIDke0A0LYaUhyA5HtANCWKSs9IVSNFIXSJ2KSs9IVSNFIVSEsVlIpCqRopCrROxXGs9IVSH0hNEqriTQpjbFslVoKB8IRA+BsS5HQh0IVA6C0QyNlDZQuB0orEcqOUNlAyhsr2/XXZFIjav0TYe4qPy7dJPn6Od+q19v8AO4fT4ndKV6s6i8L8vJCyvU0m+3u/afu2PPvSdupaweF9Os1KZa232NfivSZejrSbm6m417ubhzS+8019z0PgnhnTTkeSaydPkhcuWJ6Va+U+z+/c6H4r/wBNl1lnzMmVSp55bdtLX9u+y+xz55+XHyzDX/H+Ww4zwuct3PzX9vA5L4JJf1Pt+mvc3eF9LWa1Pq2Ys+P/AHN/CSX7nZ/DvUrDlVV6djru/eiTXp6fpvwHWTDdc+ORJPFDXa37pv2+h5OlWG3PdNPWvfZ9g6DxvFnxTMNc1rWvU+c+L+GPH1OSny4+ZSh2tN+6b+umc/8Aj+e5Z3DNT/KxwwwmWLi5rptOlS+71+wnRvyrUNN79db0YWv39juk04pnclaJoP7a+m9laCOxdNCdyn2W/X47G7q8Shb3tNP17M5/dA1WXk3Na5JzT774taa19UwUtx3d7A0C0MaBaNpTZbQDQ1oBoWw0pVIW0OaFtCWHlJpCqQ+kLpE7FZSKQqkPpCqROxWUikJtD7QmyVVxIpCbQ+xFkqviRYpjbFMlVsRQaIM8GiA4lyPgdAmB8FsUMjoHSKgbJaIZGyNkXI2SsSp+Cqn88/2vW/r8fx/BozeK5Kpd/wA0/svoZahTHL+6u0932+v8CoxcdfUP6T1Y7mDxbI1p6S9+K1sbn6/ktHJxmvoqU5YqltTSen6PRTW/dSnr1A5ulyK/zxklKFVy5c5OD7zST+d/sE8mFxyxN8p9Z3v/ANpn0LrOrxdd0V5aUrqOlw5MkZH/AHY5XKsVfKeu3w9P534Dqukx9Vvj0/1ppO3+np2J45ZZe56reTHnKS/X8z+4rw78Q102SeG3e1qd9/2PR+NfiJ9XCnI4WTjyaS/qpv0X6L5+DleB+C4Jnk5U7W0+3+Iz9RCm2l9ddzYeHG+TvL/tA8mudT6/tq6HDHKay1qXr1fZb+Rni2LGqU4u/bvo7f4bx9JXSus2uadKt62pXp/B5v8A1Eq6aaqW+zl70l7F5d5X/wAR3lMWatrfz37fU29DhWTXZr07Npvfz2M2S+VN/I7puo4D5S69Njf5aer6RSjls3dR13L8r33XbS2t/X4MVP7/AEBjvXs2Wt+gfv8Af/ophte63r5a1+4LCBbBYbBYtNC6F0MoChKpCqF0NoVQlUhVCaHUKonVcSbEWPoTZLJbFnsTZosRZHJfFmsUx1iWRq+IoHwIgdAcQyaIY+GZ4Y6GWiGUaIY+WZpY2aKyoZRplmrDhdLfot6+e5hmjXgzyl39fn5RbCz9Rzl/F9Q3LmX3Xdok3tkzvk0/bel9wUtM2/ZefTVDGKjPFBuisqVjueC5/NqumydRHS482K08+RNwtLkpf/k0l9376R6T8AdZgw42ss6qnNq2t/1T/T9DheA+HRmlctdzq9Z0tdL0zyY+L5VTlNb7ei13Oa+THLO4X9Vz8OfxzPH8a/FcGGLyuEonI3aldu7PM9fghLfq1ppvv3M+TrslvlSpN62m96/Yz1k36nV48dOXKXU/k1U1vTaT9dP1/ULHiprcrcp67ezEKjueDZMcQ+S/NS9fX/4PllZNwJJv24+SHpr3/YiyVSXJJcVxlLW+O2+793tv+DodXKTf+I5lPu+/6rfb9gy79tZoyU29LuxuPpclvjKbe3v2SXzsV0+TV+je01td9P6myOu8mtzp0/y8X6NP5+DWku96d/XTYuh4ZFrJ5L332qtp/b1PHtjuu6ust7pJcVxST3r7+5ldCYzX+1FtgtgugXQbTSJTAplOgHQlp5EpiqZdUKqhLVJEpiaYVUKqidqsgbYimMpibZK1bGF2IsbTE2yOS2MJsSxtsUyVXxXI6WJkZLNGp8sbLM8sZNFJUrGmaGzRlmhk0UlSuLVNDFZkmxiseZJ3F2sUy5ctr09mmvn1MWern+vsva9b2vqb/BvBeo6nE8uLShNzO/7mvYVPUw54Zfy1G5fZ+3YfHHq/ZLlr8ZcNU3qXN/8Ai9ndx+D5XgrNbx4olb3lyTDf6L1Z5fqulxXe1pT2W32X6s3eHPHhT0lulp/VEPJ831hYaTxfeUrV0Hi2SL4y3w3remtr6Hp//wBp9VrE1qEkl3/jR5C8q3tL9kNwdS4e0Ww8cnu/aeWeVmvx63renxzK7N7T7yt/m9t/CPPZKW2vb07EyeK3S0ZPNe00k+/dVvT/AGLYWz7Szkv019NVvUVS4JtqZ20m0tv+F+x1pzwo9NVK9u/ocCcuu69UMrq21rsv0KzKaQz8dyrdXUPJXwn6fohedcWmn9e636GGcmt+3fe9/wDRHmrb/N2aW01t9vr7A6Nx7dLpbWn87NXW+H08SyPTX/Rw1kNL8UycPL3+U2WV/Gx8c3ug5AuxHmL5Xw17gvIDo3BzsF2IeQB5BbkeYHuxbsS8gDsS5HmBtWLqhdWLqxLkpMR1QuqAqwKoS1SYrqhVUSqF1RO1SYqpiqYVMXTJ2qyAoWw6FsnVYtBpi0EZqamEqEphJjbLYeqDVmdUWqGlLcWpWGrMisJWNMiXF6Pwn8S5+lxVijTlt0t+s0/VnMrM6bpvbbbb+WzCrCWQaZE+NtWQNZDCsgSyjdluDcsgSymBZQlmG7LfG6CylrKYPOJ5wfkL8bo+aTzTn+cX5wfkD4nQ80nmmDzivON8jfG3+aV5ph84rzjfI3xtzygvKYvOKeYHZvja3kBeQyPKC8ovZp42p5AXkMzygvIL2aYNDyAuzO8gLsFyNMDnYLoS7KdCXI8xMdAOgHQLoW00xE2A2U2U2LaaRGAy2UA8QmyyAZNk2WQzJyL5EIHbaTmXzKIbYaF5hPMIQ220vzSeaQht0OYvzSecQgd1uYvzieeQgd1uYvzyeeQht1uYnnk88shuqHMV55PPIQ3VbmJ5xXnEIDqjzFecTzSENutzFeaTzCiG22onmFcyEBsdJzK5EIbbaVyJshDDpWybIQDKIQhmf//Z)",backgroundRepeat:"no-repeat",backgroundSize:"cover"}}>
                <Header />
                <div id="container" className="container">

                    <br />
                    {/* <div id="content">
                        <div id="form-bg">
                            <div id="form-overlay">

                                <div className="row">
                                    <div className=" col-md-8 col-lg-8" id="iconform">
                                        <input type="text" className="form-control" id="location"
                                            onKeyPress={this._handleKeyPress}
                                            placeholder="All Indians" />
                                        <i className="fa fa-map-marker-alt"></i>
                                    </div>



                                    <div className="col-md-2  col-lg-2">
                                        <button type="button" className="btn btn-outline-primary" id="search-btn">
                                            <i className="fa fa-search"></i>
                                            Search</button>
                                    </div>
                                </div>
        </div> */}
              
                </div>

                <div id="main-content" className="row">
                    <div className="container">
                        <div id="category" className="row">
                            { 
                                this.state.category.map((item, i) => {
                                    return (    
                                             
                                               <div>                        
                                        <NavLink to={`/productsList/${item.category}`} key={item.category}>
                                          <br/><br/>
                                          <p>{item.category}</p>
                                            <img src={item.path} alt={item.category} height="100%" width="100%"/>
                                            &nbsp;&nbsp;
                                        
                                                 &nbsp;&nbsp;
                                                  </NavLink>                                        
                                           </div>
                                    );
                                    
                                })
                            }
                        </div>
                    <br/>
                    <br/>
                    </div>
                </div>
                <Footer />
           </div>


        );
    }
}

export default List; 