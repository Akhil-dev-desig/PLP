// import React, { Component } from 'react';
// import axios from 'axios'
// class Login extends Component {
//     constructor() {
//         super();

//         //Binding text box event
//         this.state = {
//             fields: {
//                 email: '',
//                 password: '',
//                 role: '',
//                 phoneNumber: ''
//             },
//             errors: {},
//             formIsValid: true
//         }
//         this.handleChange = this.handleChange.bind(this);
//         this.submitLoginForm = this.submitLoginForm.bind(this);
//     }//end of the constructor
//     handleChange(e) {
//         let fields = this.state.fields;
//         fields[e.target.name] = e.target.value;
//         this.setState({
//             fields: fields
//         });
//         console.log(this.state.fields);
//     }
//     submitLoginForm(e) {
//         e.preventDefault();
//         if (this.validateForm()) {

//             if (this.state.fields.role == "user") {

//                 let fields = {};
//                 fields["email"] = '';
//                 fields["password"] = '';
//                 fields["role"] = '';
//                 fields["phoneNumber"] = '';

//                 this.setState({ fields: fields });
//                 alert("Login Successfully")
//                 this.props.history.push('/list');
//             }
//             else if (this.state.fields.role == "admin") {

//                 let fields = {};
//                 fields["email"] = '';
//                 fields["password"] = '';
//                 fields["role"] = '';
//                 fields["phoneNumber"] = '';

//                 this.setState({ fields: fields });
//                 alert("Login Successfully")
//                 this.props.history.push('/list');

//             }
//             // this.props.history.push('/list');
//         }
//     }//end of the submit button

//     validateForm() {
//         let fields = this.state.fields;
//         let errors = {};
//         let formIsValid = true;

//         if (!fields["email"]) {
//             formIsValid = false;
//             errors["email"] = "Please Enter Your Email Id.";
//         }
//         else if (typeof fields.email !== "undefined") {
//             if (!fields.email.match(/^([\w.%+-]+)@([\w-]+\.)+([\w]{2,})$/i)) {
//                 formIsValid = false;
//                 errors.email = "Please Enter Valid Email Id."
//             }
//         }
//         else {
//             errors.email = "";

//         }
//         if (!fields["password"]) {
//             formIsValid = false;
//             errors.password = "Please Enter Your Password.";
//         }
//         else if (typeof fields.password !== "undefined") {
//             if (!fields.password.length >= 6) {
//                 formIsValid = false;
//                 errors.password = "Password is too short."
//             }
//         }
//         else {
//             errors.password = "";

//         }
//         // if(!fields["role"]){
//         //     formIsValid=false;
//         //     errors.role="Please Select Your Role.";
//         // }

//         // else {
//         //     errors.role="";

//         // }
//         // if(!fields["phoneNumber"]){
//         //     formIsValid=false;
//         //     errors.phoneNumber="Please Enter Your Phone Number.";
//         // }
//         // else if(typeof fields.phoneNumber!=="undefined"){
//         //     if(!fields.phoneNumber.length==10){
//         //         formIsValid=false;
//         //         errors.phoneNumber="Phone Number Must Be 10 Digits."
//         //     }
//         // }
//         // else {
//         //     errors.phoneNumber="";

//         // }
//         this.setState({
//             errors: errors,
//             formIsValid: formIsValid
//         });
//         return formIsValid;
//     }
//     render() {
//         return (
//             <div className="container">

//                 <div className=" offset-lg-3 col-lg-6">
//                     <h2>Login</h2>
//                     <form method="post" name="loginForm" onSubmit={this.submitLoginForm}>

//                         <div className="form-group">
//                             <label>Email ID:</label>
//                             <input type="text" name="email" className="form-control" value={this.state.fields.email}
//                                 onChange={this.handleChange} />
//                             <div className={this.state.errors.email ? 'alert alert-danger' : ''}>
//                                 {this.state.errors.email}
//                             </div>
//                         </div>
//                         <div className="form-group">
//                             <label>Password:</label>
//                             <input type="password" className="form-control" name="password" value={this.state.fields.password}
//                                 onChange={this.handleChange} />
//                             <div className={this.state.errors.password ? 'alert alert-danger' : ''}>
//                                 {this.state.errors.password}
//                             </div>
//                         </div>
//                         <div className="form-group">
//                             <label>Role:</label>
//                             <select className="form-control" name="role" onChange={this.handleChange} >
//                                 <option value="admin">Admin</option>
//                                 <option value="user">User</option>
//                                 {/* <div className={this.state.errors.role ? 'alert alert-danger' : ''}>
//                                 {this.state.errors.role}
//                             </div> */}
//                             </select>
//                         </div>
//                         <div className="form-group">
//                             <label>Phone Number:</label>
//                             <input type="number" className="form-control" name="phoneNumber" value={this.state.fields.phoneNumber}
//                                 onChange={this.handleChange} />
//                             {/* <div className={this.state.errors.phoneNumber ? 'alert alert-danger' : ''}>
//                                 {this.state.errors.phoneNumber}
//                             </div> */}
//                         </div>
//                         <div className="form-group">
//                             <input type="submit" className="btn btn-success" value="Login" />
//                             {/* disabled={!this.state.formIsValid} */}
//                         </div>

//                     </form>
//                 </div>


//             </div>
//         );
//     }
// }
// export default Login;




import React from 'react';
import Header from './header.component';
import '../static/css/reglogin.css';
import { NavLink } from 'react-router-dom';
import Footer from './footer.component';
import axios from 'axios';
import NotificationSystem from 'react-notification-system';
class Login extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            email: '',
            password: '',
            role:'',
            otp1:''
        }
        this.onChangeOTP=this.onChangeOTP.bind(this);
        this.getOTP=this.getOTP.bind(this);
        this.getVerificationCode=this.getVerificationCode.bind(this);
    }

    _notificationSystem = null

    _addNotification = (level, msg) => {
        //event.preventDefault();
        this._notificationSystem.addNotification({
            message: msg,
            level: level
        });
    }

    componentDidMount() {
        this._notificationSystem = this.refs.notificationSystem;

    }

    onChangeOTP(e){
        this.setState({
        otp1:e.target.value
        })
    }

    getOTP(){
        let otp=Math.random().toString().substr(2,4);
        return otp;
    }
    getLogIn = (e) => {
        e.preventDefault();
        this.otp = this.getOTP();
    alert('Generated OTP is:'+this.otp)             

            }
        

    
    getVerificationCode() {
console.log(this.otp);
        this.enterOtp = this.state.otp1;
        if (this.enterOtp == this.otp) {
            this._addNotification("success", "You have successfully LogIn.");
            axios.post('http://localhost:5000/user/login', this.state).then(res => {
            console.log(res.data);

          
            if (res.status === 200) {
                console.log(res.data);
                localStorage.setItem("UserObject", JSON.stringify(res.data));
               console.log(this.state.role);
               
            if(this.state.role==="admin")
            window.location = '/myaccount';
            else if(this.state.role=="user")
  
             window.location = '/list';
          return('/list');
            }
        })
            .catch(err => {
                console.log(err)
                console.log(err.response.data.msg);
                if (err.response.status === 401) {
                    this._addNotification("error", `${err.response.data.msg}`);
                }
                console.error(err.response);
                var errors = err.response.data.errors === undefined ? [] : err.response.data.errors;

                for (var i = 0; i < errors.length; i++) {
                    this._addNotification("error", `${i + 1} -> ${errors[i].param}: ${errors[i].msg}`)
                }


            });

          
        }
        else {
        alert('please enter valid otp');
         window.location.reload();
      }
        
    
    }

    render() {
        return (
          <div>
              <Header/>
                <div >      
 
<div class="container">

                    <p style={{ fontWeight: 'bold' }}>LogIn</p>


                    <form method="POST" >
                        <div className="form-group " id="iconlogin">
                            <input type="email"
                                value={this.state.email}
                                onChange={(e) => { this.setState({ email: e.target.value }) }}
                                className="form-control text-light" name="email" id="email"
                                 aria-describedby="emailHelp" placeholder="Enter email" />
                            <i className="fas fa-envelope"></i>

                        </div>
                        <div className="form-group" id="iconlogin2">
                            <input type="password"
                                value={this.state.password}
                                onChange={(e) => { this.setState({ password: e.target.value }) }}
                                className="form-control" name="password" id="password" 
                                placeholder="Password" />
                            <i className="fas fa-unlock-alt"></i>
                        </div>
                        <div className="form-group" id="iconlogin2">
                            <input type="number"
                                value={this.state.phoneNumber}
                                onChange={(e) => { this.setState({ phoneNumber: e.target.value }) }}
                                className="form-control" name="phoneNumber" id="phoneNumber"
                                 placeholder="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Phone Number" />
                            <i className="fas fa-phone-alt"></i>
                        </div>
                        <select className="form-control" name="role" 
                                onChange={(e) => { this.setState({ role: e.target.value }) }} 
                                placeholder="Choose Your role"  required>
                        <option value="select">Select Role</option>
                        <option value="admin">Admin</option>
                        <option value="user">User</option>
                        </select>
<br/>
                        <button type="submit" onClick={this.getLogIn} className="btn btn-outline-success">Get OTP</button>
                        <br/>
                        <input type="number" className="form-control" name="otp1" id="otp1" onChange={this.onChangeOTP} 
                               value={this.state.otp1} placeholder="Enter Yor OTP" />
                               <br/>
                        <button type="submit" onClick={this.getVerificationCode} className="btn btn-outline-info">Submit</button>

                        <p >Forgot Password?</p>
                        <NavLink to='/user/register'><p >New User? Register Here</p></NavLink>
                    </form>

                </div>
                <NotificationSystem ref="notificationSystem" />

                <br/>
                <br/>
                <Footer />

                </div>
            </div>


           

        

        );
    }
}

export default Login;