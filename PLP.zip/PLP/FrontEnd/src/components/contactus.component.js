import React, { Component } from 'react';
import Header from './header.component';
import Footer from './footer.component';

class ContactUs extends Component {
    constructor(props) {
        super(props)
        this.submit = this.submit.bind(this);
    }
    submit() {
        alert('Message Sent Successfully...\n Thank You For Your Shopping')
    }
    render() {
        return (

            <div>
                <div style={{ backgroundImage: "url(https://www.barraques.cat/pngfile/big/0-7755_nature-pier-bridge-d-river-water-sunset-night.jpg)", backgroundRepeat: "no-repeat", backgroundSize: "cover" }}>
                    <Header />


                    <div className="row text-light">

                        <div className="offset-lg-3 col-lg-7">
                            <h1>Contact Us  ....</h1>

                            <input type="text" placeholder="Enter Your Name" required />

                            <input type="text" required placeholder="Enter email" />


                            <label>
                                <b>Any Issues You have</b>
                                <span style={{ color: 'red' }}>*</span>
                            </label>
                            <textarea cols={100} rows={8} required placeholder="Including the brand, models and any other accessories" required>
                            </textarea>
                            <button className="btn btn-primary" align="center" onClick={this.submit}>Send Message</button>
                            <br /> <br />      <br /> <br />

                        </div>
                    </div>
                    <Footer />
                </div>



            </div>

        )

    }

}

export default ContactUs;