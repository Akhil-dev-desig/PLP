import React from 'react';
import Header from './header.component'
import axios from 'axios';
import '../static/css/reglogin.css';
import Form from 'react-validation/build/form';
import Input from 'react-validation/build/input';
import { isEmail } from 'validator';
import NotificationSystem from 'react-notification-system';
import Footer from './footer.component'

const required = (value, props) => {
    if (!value || (props.isCheckable && !props.checked)) {
        return <span className="form-error is-visible">Required</span>;
    }
};

const email = (value) => {
    if (!isEmail(value)) {
        return <span className="form-error is-visible">${value} is not a valid email.</span>;
    }
};



class Register extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            email: '',
            password: '',
            phoneNumber: '',
            error: ''

        };
    }

    _notificationSystem = null

    _addNotification = (level, msg) => {
        
        this._notificationSystem.addNotification({
            message: msg,
            level: level
        });
    }

    componentDidMount() {
        this._notificationSystem = this.refs.notificationSystem;

    }

    getRegister = (e) => {
        e.preventDefault();
        axios.post('http://localhost:5000/user/register', this.state).then(res => {

            console.log(res.data);

            this._addNotification("success", "You have successfully registered.");
                window.location = '/user/login';
            
        })
            .catch(err => {
                console.log(err)
                console.error(err.response);
                var errors = err.response.data.errors === undefined ? [] : err.response.data.errors;

                for (var i = 0; i < errors.length; i++) {
                    this._addNotification("error", `${i + 1} -> ${errors[i].param}: ${errors[i].msg}`)
                }


            });

    }

    render() {
        return (
            <div>
                <Header/>
                <div style={{ backgroundImage:"url(https://www.barraques.cat/pngfile/big/0-7755_nature-pier-bridge-d-river-water-sunset-night.jpg)"}}>>

                <div className="container">
                 
                  
                        <p style={{ fontWeight: 'bold' }}>Create an Account</p>
                        <div >

                            <Form method="POST" onSubmit={this.getRegister}>

                                <div className="form-group">
                                    <Input type="email" className="form-control"
                                        value={this.state.email}
                                        onChange={(e) => { this.setState({ email: e.target.value }) }}
                                        name="email" id="Email1"
                                        validations={[required, email]}
                                       placeholder="Enter email" />
                                    
                                </div>
                                <div className="form-group">
                                    <Input type="password"
                                        value={this.state.password}
                                        onChange={(e) => { this.setState({ password: e.target.value }) }}
                                        className="form-control" name="password" id="password1"
                                        validations={[required]}
                                        placeholder="Password" />
                                </div>

                                  <div className="form-group">
                                    <Input type="number"
                                        value={this.state.phoneNumber}
                                        onChange={(e) => { this.setState({ phoneNumber: e.target.value }) }}
                                        className="form-control" name="phoneNumber" id="phoneNumber"
                                        validations={[required]}
                                        placeholder="Phone Number" />
                                </div>
                                <button type="submit" className="btn btn-outline-success" >Register</button>


                            </Form>



                    </div>
                </div>
                <NotificationSystem ref="notificationSystem" />

                <br/>
                <br/>
                <Footer />
            </div>
            </div>

        );
    }
}

export default Register;