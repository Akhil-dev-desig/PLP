import React from 'react';
import Header from './header.component';
import Footer from './footer.component';
//import '../static/css/list.css';
import { category } from '../config/category';
import { NavLink } from 'react-router-dom';
import axios from 'axios';
class ProductsList extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            data: [],
            category1: category,
            length: [1, 2, 3]
        };
    }
    componentDidMount() {
        let path = this.props.match.params.category;
        let path1 = this.props.match.params.city;
        
        console.log(this.props.match.params.category);
        if (path) {


            axios.get('http://localhost:5000/item/?category=' + path)
                .then((res) => {
                    this.setState({ data: res.data });
                }).catch(err => console.error(err))
        } else {
            axios.get('http://localhost:5000/item/cities/?city=' + path1)
                .then((res) => {
                    this.setState({ data: res.data });
                }).catch(err => console.error(err))

        }
    }

    render() {

        return (

            <div>
                <Header/>
                <div className="container">
                        {/* <div id="categories" className="row">
                        {
                            this.state.category1.map((item) => {
                                return (
                                    <div className="col-md-3" key={item.category}>
                                      <NavLink to={`/item/${item._id}`}><p id="cate-ad">{item.category} </p></NavLink>
                                    </div>

                                );
                            })
                        }

                    </div> */}
                    <hr />
                    {
                        this.state.data.length == 0 ? <NoAdd /> : <ListItem data={this.state.data} />
                    }
                </div>

                 <Footer />
            </div>

        );
    }
}

const ListItem = (props) => (
    <div>
        {
            props.data.map((item) => {
                return (
                    <NavLink to={`/item/${item._id}`} key={item._id}>
                        {console.log(item._id)}
                        <div className="row">
                            <div id="list">
                                <div id="item-img">
                                    <img src={'http://localhost:5000/uploads/' + item.photo[0]} alt="List-Item" height='120' id="img" />

                                </div>
                                <div id="item-detail">
                                    <p id="product-name">{item.title}</p>
                                    <p id="product-cate">{item.category}</p>
                                  
                                </div>
                                <div id="item-icon">
                                    <i className="far fa-heart" ></i>
                                </div>


                            </div>
                        </div>
                    </NavLink>



                );

            })
        }


    </div>
)

const NoAdd = () => (
    <div style={{ margin: '50px auto', width: '80%', borderRadius: '20px', height: '300px' }}>
        <img src={require('../assests/images/robot.jpg')} alt="Empty" height="150" width="150"
            style={{ margin: '10px auto', display: 'block' }} />
        <h4>Sorry There is no Addvertisement</h4>

    </div>
)



export default ProductsList;