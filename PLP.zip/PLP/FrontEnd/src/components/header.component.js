import React from 'react';

import '../static/css/header.css';
import { NavLink, Link } from 'react-router-dom';

const currentUser = JSON.parse(localStorage.getItem('UserObject'));

class Header extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            userid: currentUser == undefined ? 'My Account' : currentUser.email

        };
        //console.log(this.props);
    }
    render() {
        return (
            <div>
                <nav className="navbar navbar-expand-lg navbar-dark bg-info">

                    <Link to="/"
                        className="navbar-brand">Home</Link>
                    <Link to="/about"
                        className="navbar-brand">About</Link>
                    <Link to="/contactus"
                        className="navbar-brand">Contact</Link>
                    <button className="navbar-toggler" type="button" data-toggle="collapse"
                        data-target="#collapsibleNavbar">
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="ml-auto">
                        <div className="flexbtn" id="btn-group">

                            {
                                (!currentUser ? <NavLink to='/user/login' >

                                    <button type="button" className="btn btn-danger "
                                        id="account-btn" >
                                        <i className="fa fa-user" ></i>
                                        &nbsp;&nbsp;
                         My Account</button>
                                </NavLink> :

                                    <div className="dropdown resbtn2">
                                        <button className="btn btn-default" type="button"
                                            id="dropdownMenuButton" data-toggle="dropdown"
                                            aria-haspopup="true" aria-expanded="false">
                                            {this.state.userid.split(/@[a-z]*.com/)}
                                        </button>
                                        <div className="dropdown-menu"
                                            aria-labelledby="dropdownMenuButton" >
                                            <NavLink to='/myaccount'><span className="dropdown-item">
                                                My Account</span></NavLink>
                                            <span className="dropdown-item" onClick={
                                                () => {
                                                    localStorage.removeItem('UserObject');
                                                    window.location = '/'
                                                }
                                            }>LogOut</span>

                                        </div>

                                    </div>

                                )
                            }




                            <div>

                                <NavLink to={!currentUser ? '/user/login' : '/post'}>
                                    <button type="button" id="ad-btn" className="btn btn-outline-warning btn-lg resbtn3" >
                                        Post  Add</button></NavLink>

                            </div>
                        </div>
                    </div>

                </nav>




            </div>

        );
    }
}

export default Header;