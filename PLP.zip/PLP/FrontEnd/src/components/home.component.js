import React, { Component } from 'react';
import Header from './header.component'
import Footer from './footer.component'
class Home extends Component {
    render() {
        return (
            <div>
                <Header/>
                <div  style={{ backgroundImage:"url(http://theartinspiration.com/wp-content/uploads/2013/08/hd-wallpaper-nature09.jpg)",backgroundRepeat:"no-repeat", backgroundSize:"cover"}}>>
               <h4 className="text-light"><marquee><i><b>Welcome to Online shopping mall</b></i></marquee></h4>
               <div className="col-lg-8 col-md-12 col-sm-12">
             <img src="https://media3.giphy.com/media/XEaxZeukIWhV5d1FPF/giphy.gif?cid=790b7611bfd8d4a989988d013e2cf65b51118c2b1ce2d66f&rid=giphy.gif" style={{marginLeft: 300, width: 800, height: 400}}/>
             </div>
             <br/><br/>
             <h5 className="text-dark text-center"><b><i>Whoever said that money can't buy happiness simply didn't know where to go shopping...</i></b></h5>
<br/><br/>
                </div>

            <Footer/>
</div>
        )
    }
}
export default Home;
