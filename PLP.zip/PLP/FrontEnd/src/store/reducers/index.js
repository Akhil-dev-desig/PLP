import {combineReducers} from 'redux';
import Reducer from './Reducer';
// take object as parameter
export default combineReducers ({
    RootReducer : Reducer

})