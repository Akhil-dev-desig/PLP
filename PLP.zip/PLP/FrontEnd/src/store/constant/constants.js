const actionTypes = {
    USER_NAME :'username'
}
export default actionTypes;